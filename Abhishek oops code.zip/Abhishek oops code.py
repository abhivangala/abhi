import tkinter as tk
from tkinter import simpledialog, messagebox, ttk


class CenterWindow:
    """
    Utility class to center the main window on the screen.
    """
    def __init__(self, window):
        """
        Initializes the CenterWindow object with the given window.

        Parameters:
        - window: Tkinter window to be centered.
        """
        self.window = window
        self.center_window()

    def center_window(self):
        """
        Centers the window on the screen.
        """
        self.window.update_idletasks()
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        x = (self.window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.window.winfo_screenheight() // 3) - (height // 3)
        self.window.geometry('{}x{}+{}+{}'.format(width, height, x, y))


class acc:
    """
    Represents a generic bank acc.
    """
    def __init__(self, name, acc_number, initial_blnc=0):
        """
        Initializes an acc object with the given attributes.

        Parameters:
        - name: acc_holder's_name.
        - acc_no.: acc-number.
        - initial_bal: Initial blnc of the acc (default is 0).
        """
        self.__name = name
        self.__acc_number = acc_number
        self.__initial_blnc = initial_blnc
        self.__blnc = initial_blnc
        self.__transactions = [f"Initial balance: {initial_blnc}"]

    def deposit(self, amount):
        """
        Adds funds to the acc.

        Parameters:
        - amount: Amount to be deposited.

        Returns:
        - True if deposit is successful, False otherwise.
        """
        if amount > 0:
            self.__blnc += amount
            self.__transactions.append(f"Deposit: {amount}")
            return True
        else:
            return False

    def withdraw(self, amount):
        """
        Deducts funds from the acc.

        Parameters:
        - amount: Amount to be withdrawn.

        Returns:
        - True if withdrawal is successful, False otherwise.
        """
        if 0 < amount <= self.__blnc:
            self.__blnc -= amount
            self.__transactions.append(f"Withdrawal: {amount}")
            return True
        else:
            return False

    def get_initial_blnc(self):
        """
        Returns the initial balance of acount.
        """
        return self.__initial_blnc

    def check_blnc(self):
        """
        Returns the current Account-blnc.
        """
        return self.__blnc

    def get_transaction_history(self):
        """
        Returns the transaction history of the acc.
        """
        return self.__transactions

    def __str__(self):
        """
        Returns a acc's string-representation.
        """
        return f"account Number: {self.__acc_number}\nName: {self.__name}\nbalance: {self.__blnc}"


class Checkingacc(acc):
    """
    Represents a checking acc.
    """
    transaction_fee = 0.5  # Fixed transaction fee for all checking accs

    def __init__(self, name, acc_number, initial_blnc=0, bank_app_instance=None):
        """
        Initializes a Checkingacc object with the given attributes.

        Parameters:
        - name: The acc-holder's Name.
        - acc_number: acc-no.
        - initial_bal: Initial balance of the acc (default is 0).
        - bank_app_instance: Instance of BankApp class (default is None).
        """
        super().__init__(name, acc_number, initial_blnc)
        self.bank_app_instance = bank_app_instance

    def withdraw(self, amount):
        """
        Overrides the withdraw method to include transaction fee.

        Parameters:
        - amount: Amount to be withdrawn.

        Returns:
        - True if withdrawal is successful, False otherwise.
        """
        total_amount = amount + self.transaction_fee
        if 0 < total_amount <= self.check_blnc():
            self._acc__blnc -= total_amount
            self._acc__transactions.append(f"Withdrawal: {amount}")
            self._acc__transactions.append(f"Transaction Fee: {self.transaction_fee}")
            return True
        else:
            return False


class Savingsacc(acc):
    """
    Represents a savings acc.
    """
    interest_rate = 0.02  # Fixed interest rate for all savings accs

    def __init__(self, name, acc_number, initial_blnc=0, bank_app_instance=None):
        """
        Initializes a Savingsacc object with the given attributes.

        Parameters:
        - name: The acc-holder's Name.
        - acc_number: acc-no.
        - initial_blnc: Initial balance of the acc (default is 0).
        - bank_app_instance: Instance of BankApp class (default is None).
        """
        super().__init__(name, acc_number, initial_blnc)
        self.bank_app_instance = bank_app_instance

    def add_interest(self):
        """
        it adds the interest to acc bal based on fixed interest rate.
        """
        interest = self.check_blnc() * self.interest_rate
        self.deposit(interest)
        if self.bank_app_instance:
            self.bank_app_instance.process_transaction(self, interest, "deposit")


class Bank:
    """
    Manages bank accs.
    """
    def __init__(self, bank_app_instance):
        """
        Initializes a Bank object with the given bank app instance.

        Parameters:
        - bank_app_instance: Instance of BankApp class.
        """
        self.__accs = {}
        self.bank_app_instance = bank_app_instance

    def create_acc(self, name, acc_number, acc_type, initial_blnc=0):
        """
        Creates a new acc.

        Parameters:
        - name: The acc-holder's Name.
        - acc_number: acc-no.
        - acc_type indicates the type of acc (checking or savings).
        - initial_blnc: The acc's initial blnc (defaults to zero).


        Returns:
        - True if acc creation is successful, False otherwise.
        """
        if acc_number not in self.__accs:
            if acc_type == "Checking":
                self.__accs[acc_number] = Checkingacc(name, acc_number, initial_blnc, self.bank_app_instance)
            elif acc_type == "Savings":
                self.__accs[acc_number] = Savingsacc(name, acc_number, initial_blnc, self.bank_app_instance)
            return True
        else:
            return False

    def get_acc(self, acc_number):
        """
        Retrieves an acc by acc number.

        Parameters:
        - acc_number: acc number.

        Returns:
        - acc object if found, None otherwise.
        """
        return self.__accs.get(acc_number)


class BankApp:
    """
    Main GUI application for bank acc management.
    """
    def __init__(self, root):
        """
        Initializes the BankApp object with the given root window.

        Parameters:
        - root: Tkinter root window.
        """
        self.root = root
        self.root.title("Bank Account Management")
        self.root.geometry("600x300")  # Set the size of the main window

        # Initialize Bank instance
        self.bank = Bank(self)

        # Creating the frame for holding the buttons made.
        button_frame = tk.Frame(self.root, bg='lightgrey', bd=2, relief=tk.GROOVE)
        button_frame.pack(pady=20)

        # Button style
        button_style = {'padx': 20, 'pady': 10, 'bg': 'deep sky blue', 'fg': 'white', 'font': ('Arial', 12), 'bd': 2}

        # Buttons
        create_checking_btn = tk.Button(button_frame, text="Create Checking Account", command=lambda: self.create_acc_popup("Checking"), **button_style)
        create_checking_btn.grid(row=0, column=0, padx=10, pady=10)
        create_savings_btn = tk.Button(button_frame, text="Create Savings Account", command=lambda: self.create_acc_popup("Savings"), **button_style)
        create_savings_btn.grid(row=0, column=1, padx=10, pady=10)
        deposit_btn = tk.Button(button_frame, text="Deposit", command=self.deposit_popup, **button_style)
        deposit_btn.grid(row=1, column=0, padx=10, pady=10)
        withdraw_btn = tk.Button(button_frame, text="Withdraw", command=self.withdraw_popup, **button_style)
        withdraw_btn.grid(row=1, column=1, padx=10, pady=10)
        check_blnc_btn = tk.Button(button_frame, text="Check balance", command=self.check_blnc_popup, **button_style)
        check_blnc_btn.grid(row=2, column=0, padx=10, pady=10)
        transaction_history_btn = tk.Button(button_frame, text="Transaction History", command=self.transaction_history_popup, **button_style)
        transaction_history_btn.grid(row=2, column=1, padx=10, pady=10)

        # Initialize self.tree
        self.tree = None

        # Center the main window
        CenterWindow(self.root)

    def create_acc_popup(self, acc_type):
        """
        Displays a popup window to create a new acc.

        Parameters:
        - acc_type: Type of acc (Checking or Savings).
        """
        popup = tk.Toplevel(self.root)
        popup.title(f"Create {acc_type} Account")
        popup.configure(bg='lightgrey')

        button_style = {'padx': 20, 'pady': 10, 'bg': 'deep sky blue', 'fg': 'white', 'font': ('Arial', 12), 'bd': 2}
        
        # Entry fields
        tk.Label(popup, text="Account Number:", font=('Arial', 12), bg='lightgrey').grid(row=0, column=0, padx=10, pady=10)
        acc_number_entry = tk.Entry(popup, font=('Arial', 12))
        acc_number_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(popup, text="Name:", font=('Arial', 12), bg='lightgrey').grid(row=1, column=0, padx=10, pady=10)
        name_entry = tk.Entry(popup, font=('Arial', 12))
        name_entry.grid(row=1, column=1, padx=10, pady=10)

        tk.Label(popup, text="Initial balance:", font=('Arial', 12), bg='lightgrey').grid(row=2, column=0, padx=10, pady=10)
        initial_blnc_entry = tk.Entry(popup, font=('Arial', 12))
        initial_blnc_entry.grid(row=2, column=1, padx=10, pady=10)

        # Button to confirm acc creation
        confirm_button = tk.Button(popup, text=f"Create {acc_type} Account", command=lambda: self.create_acc(acc_number_entry.get(), name_entry.get(), initial_blnc_entry.get(), acc_type, popup), **button_style)
        confirm_button.grid(row=3, column=0, columnspan=2, padx=10, pady=10)

    def deposit_popup(self):
        """
        Displays a popup window for depositing funds into an Account.
        """
        button_style = {'padx': 20, 'pady': 10, 'bg': 'deep sky blue', 'fg': 'white', 'font': ('Arial', 12), 'bd': 2}

        acc_number = simpledialog.askstring("Deposit", "Enter Account number:")
        if acc_number:
            acc = self.bank.get_acc(acc_number)
            if acc:
                # Create the deposit dialog window
                deposit_window = tk.Toplevel(self.root)
                deposit_window.title("Deposit")
                deposit_window.attributes("-topmost", True)  # Keep the window on top
                deposit_window.grab_set()  # Prevent interaction with other windows until this window is closed

                # Set the width of the deposit window
                deposit_window.geometry("350x250")

                # Display acc details including current blnc
                acc_details_label = tk.Label(deposit_window, text=f"Account Number: {acc_number}\nName: {acc._acc__name}\nCurrent balance: {acc.check_blnc()}", font=('Arial', 12))
                acc_details_label.pack(padx=10, pady=10)

                # Entry field for amount
                amount_label = tk.Label(deposit_window, text="Enter amount to deposit:", font=('Arial', 12))
                amount_label.pack(padx=10, pady=10)
                amount_entry = tk.Entry(deposit_window, font=('Arial', 12))
                amount_entry.pack(padx=10, pady=10)

                # Function to handle deposit
                def deposit_amount():
                    amount = amount_entry.get()
                    if amount:
                        if acc.deposit(float(amount)):
                            messagebox.showinfo("Success", "Deposit successful.")
                            deposit_window.destroy()  # Destroy the deposit window after successful deposit
                            self.update_transaction_history(acc)
                        else:
                            messagebox.showerror("Error", "Deposit amount must be a positive number.")
                    else:
                        messagebox.showerror("Error", "Amount field is required.")

                # Button to confirm deposit
                confirm_button = tk.Button(deposit_window, text="Deposit", command=deposit_amount, **button_style)
                confirm_button.pack(padx=10, pady=10)

                # Focus the deposit window
                deposit_window.focus_force()
            else:
                messagebox.showerror("Error", "Account not found.")

    def withdraw_popup(self):
        """
        Displays a popup window for withdrawing funds from an acc.
        """
        button_style = {'padx': 20, 'pady': 10, 'bg': 'deep sky blue', 'fg': 'white', 'font': ('Arial', 12), 'bd': 2}

        acc_number = simpledialog.askstring("Withdraw", "Enter Account number:")
        if acc_number:
            acc = self.bank.get_acc(acc_number)
            if acc:
                def withdraw():
                    amount = amount_entry.get()
                    if amount:
                        if acc.withdraw(float(amount)):
                            messagebox.showinfo("Success", "Withdrawal successful.")
                            withdraw_window.destroy()  # Destroy the withdrawal window after successful withdrawal
                            self.update_transaction_history(acc)
                        else:
                            messagebox.showerror("Error", "Insufficient funds or invalid amount.")
                    else:
                        messagebox.showerror("Error", "Amount field is required.")

                # Create the withdrawal dialog window
                withdraw_window = tk.Toplevel(self.root)
                withdraw_window.title("Withdraw")
                withdraw_window.attributes("-topmost", True)  # Keep the window on top
                withdraw_window.grab_set()  # Prevent interaction with other windows until this window is closed

                # Set the width of the withdraw window
                withdraw_window.geometry("350x250")

                # Display acc details including current blnc
                acc_details_label = tk.Label(withdraw_window, text=f"Account Number: {acc_number}\nName: {acc._acc__name}\nCurrent balance: {acc.check_blnc()}", font=('Arial', 12))
                acc_details_label.pack(padx=10, pady=10)

                # Entry field for amount
                amount_label = tk.Label(withdraw_window, text="Enter amount to withdraw:", font=('Arial', 12))
                amount_label.pack(padx=10, pady=10)
                amount_entry = tk.Entry(withdraw_window, font=('Arial', 12))
                amount_entry.pack(padx=10, pady=10)

                # Button to confirm withdrawal
                confirm_button = tk.Button(withdraw_window, text="Withdraw", command=withdraw, **button_style)
                confirm_button.pack(padx=10, pady=10)

                # Focus the withdrawal window
                withdraw_window.focus_force()
            else:
                messagebox.showerror("Error", "Account not found.")

    def check_blnc_popup(self):
        """
        Displays a popup window to check the blnc of an acc.
        """
        button_style = {'padx': 20, 'pady': 10, 'bg': 'deep sky blue', 'fg': 'white', 'font': ('Arial', 12), 'bd': 2}
        acc_number = simpledialog.askstring("Check balance", "Enter Account number:")
        if acc_number:
            acc = self.bank.get_acc(acc_number)
            if acc:
                # Create the blnc popup window
                blnc_popup = tk.Toplevel(self.root)
                blnc_popup.title("balance")
                blnc_popup.geometry("300x150")
                blnc_popup.attributes("-topmost", True)

                # Display name, acc type, and blnc
                name_label = tk.Label(blnc_popup, text=f"Name: {acc._acc__name}", font=('Arial', 12))
                name_label.pack(pady=5)
                acc_type_label = tk.Label(blnc_popup, text=f"Account Type: {type(acc).__name__}", font=('Arial', 12))
                acc_type_label.pack(pady=5)
                blnc_label = tk.Label(blnc_popup, text=f"Current balance: {acc.check_blnc()}", font=('Arial', 12))
                blnc_label.pack(pady=5)

            else:
                messagebox.showerror("Error", "Account not found.")

    def transaction_history_popup(self):
        """
        Displays a popup window to show the transaction history of an acc.
        """
        button_style = {'padx': 20, 'pady': 10, 'bg': 'deep sky blue', 'fg': 'white', 'font': ('Arial', 12), 'bd': 2}
        acc_number = simpledialog.askstring("Transaction History", "Enter Account number:")
        if acc_number:
            acc = self.bank.get_acc(acc_number)
            if acc:
                history = acc.get_transaction_history()
                popup = tk.Toplevel(self.root)
                popup.title("Transaction History")
                popup.geometry("600x600")

                # Display name, acc type, and current blnc
                name_label = tk.Label(popup, text=f"Name: {acc._acc__name}", font=('Arial', 12))
                name_label.pack(pady=5)
                acc_type_label = tk.Label(popup, text=f"Account Type: {type(acc).__name__}", font=('Arial', 12))
                acc_type_label.pack(pady=5)
                current_blnc_label = tk.Label(popup, text=f"Current balance: {acc.check_blnc()}", font=('Arial', 12))
                current_blnc_label.pack(pady=5)

                # Initialize self.tree as a ttk.Treeview widget
                self.tree = ttk.Treeview(popup, columns=("Transaction", "Amount"), show="headings")
                self.tree.heading("Transaction", text="Transaction")
                self.tree.heading("Amount", text="Amount")
                self.tree.pack(pady=10)

                # Update transaction history
                self.update_transaction_history(acc)

            else:
                messagebox.showerror("Error", "Account not found.")

    def create_acc(self, acc_number, name, initial_blnc, acc_type, popup):
        """
        Creates a new acc based on user input.

        Parameters:
        - acc_number: acc number entered by the user.
        - name: Name of the acc holder.
        - initial_blnc: Initial blnc of the acc.
        - acc_type: Type of acc (Checking or Savings).
        - popup: The popup window for creating an acc.
        """
        if acc_number and name and initial_blnc:
            if float(initial_blnc) >= 0:
                if self.bank.create_acc(name, acc_number, acc_type, float(initial_blnc)):
                    messagebox.showinfo("Success", f"{acc_type} Account created successfully.")
                    popup.destroy()  
                else:
                    messagebox.showerror("Error", "Account number already exists.")
            else:
                messagebox.showerror("Error", "Initial balance must be a non-negative number.")
        else:
            messagebox.showerror("Error", "All fields are required.")

    def process_transaction(self, acc, amount, transaction_type):
        """
        Processes a transaction (deposit or withdrawal) for an acc.

        Parameters:
        - acc: The acc object involved in the transaction.
        - amount: The amount of money involved in the transaction.
        - transaction_type: Type of transaction (deposit or withdraw).
        """
        if amount:
            if transaction_type == "deposit":
                if acc.deposit(float(amount)):
                    messagebox.showinfo("Success", "Deposit successful.")
                else:
                    messagebox.showerror("Error", "Deposit amount must be a positive number.")
            elif transaction_type == "withdraw":
                if acc.withdraw(float(amount)):
                    messagebox.showinfo("Success", "Withdrawal successful.")
                else:
                    messagebox.showerror("Error", "Insufficient funds or invalid amount.")
        else:
            messagebox.showerror("Error", "Amount field is required.")

    def update_transaction_history(self, acc):
        """
        Updates the transaction history displayed in the treeview widget.

        Parameters:
        - acc: The acc whose transaction history needs to be displayed.
        """
        if self.tree and not self.tree.winfo_exists():
            return

        if isinstance(self.tree, ttk.Treeview):
            history = acc.get_transaction_history()
            initial_blnc = acc.get_initial_blnc()
            for item in history:
                self.tree.insert("", "end", values=(item.split(":")[0], item.split(":")[1]))

if __name__ =="__main__":

    root = tk.Tk()
    app = BankApp(root)
    root.mainloop()
